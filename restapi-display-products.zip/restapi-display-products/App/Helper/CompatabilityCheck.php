<?php

namespace Radp\App\Helper;

class CompatabilityCheck{
    /**
     * This function is used to check  our dependencies
     *
     * @return bool
     */
    public function isCompatabilityCheck(): bool
    {
        if(!$this->isWoocommerceActive()){
            return false;
        }elseif (!$this->isEnvironmentCompatible()){
            return false;
        }elseif (!$this->isWordPressCompatible()){
            return false;
        }elseif (!$this->isWoocommerceCompatible()){
            return false;
        }
        return true;
    }

    /**
     * This is sure the woocommerce is activated or not
     *
     * @return bool
     */
    public function isWoocommerceActive(): bool
    {
        $activate_plugins = get_site_option('active_plugins');
        if(is_multisite()){
            $activate_plugins = array_merge($activate_plugins, get_site_option('active_sitewide_plugins', array()));
        }
        return (in_array('woocommerce/woocommerce.php', $activate_plugins) || array_key_exists('woocommerce/woocommerce.php', $activate_plugins));

    }

    /**
     * This function is used to display the admin notice
     *
     * @return void
     */
    function displayNotices()
    {
        $message = $this->getCompatabilityNotice();
        echo '<div class="notice notice-error"><p><strong>' . esc_html($message) . '</strong></p></div>';
    }

    /**
     * This function return the notice
     *
     * @return string
     */
    public function getCompatabilityNotice(): string
    {
        $message = '';
        if(!$this->isWoocommerceActive()) {
            $message = esc_html__(' Woocommerce  must be installed and activated in-order to use ', 'auto-apply-coupon-code ') . RDP_PLUGIN_NAME;
        }elseif (!$this->isEnvironmentCompatible()){
            $message = RDP_PLUGIN_NAME.esc_html__(' is inactive. Because, it requires minimum PHP version of ','auto-apply-coupon-code ').RDP_MINIMUM_PHP_VERSION;
        }elseif (!$this->isWordPressCompatible()){
            $message = RDP_PLUGIN_NAME.esc_html__(' is inactive. Because, it requires minimum WordPress version of ','auto-apply-coupon-code ').RDP_MINIMUM_WP_VERSION;
        }elseif(!$this->isWoocommerceCompatible()){
            $message = RDP_PLUGIN_NAME.esc_html__(' is inactive. Because, it requires minimum Woocommerce version of ','auto-apply-coupon-code ').RDP_MINIMUM_WC_VERSION;

        }
        return $message;
    }

    /**
     * This function check the php version
     *
     * @return bool|int
     */
    public function isEnvironmentCompatible(){
        return version_compare(PHP_VERSION, RDP_MINIMUM_PHP_VERSION, '>=');
    }

    /**
     * This function check  the WordPress version
     *
     * @return bool|int
     */
    public function isWordPressCompatible(){
        return (!RDP_MINIMUM_WP_VERSION) ? true : version_compare(get_bloginfo('version'), RDP_MINIMUM_WP_VERSION, '>=');
    }

    /**
     * This function return the woocommerce version
     *
     * @return mixed|string
     */
    public function wooVersion(){
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $plugin_folder = get_plugin_data(WP_PLUGIN_DIR . '/woocommerce/woocommerce.php');
        return isset($plugin_folder['Version']) ? $plugin_folder['Version'] : '1.0.0';
    }

    /**
     * This function check the woocommerce version
     *
     * @return bool|int
     */
    public function isWoocommerceCompatible(){
        $wc_version = $this->wooVersion();
        return (!RDP_MINIMUM_WC_VERSION) ? true : version_compare($wc_version, RDP_MINIMUM_WC_VERSION, '>=');

    }
}