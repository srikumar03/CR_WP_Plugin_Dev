<?php
namespace Radp\App\Helper;

class RestApiHelper{
    /**
     * This function is if the function is existed or not
     *
     * @param $function
     * @return bool
     */
    public function checkMethods($function): bool
    {
        if(function_exists($function)) {
            return true;
        }
        return false;
    }


}