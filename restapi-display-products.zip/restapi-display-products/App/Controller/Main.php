<?php

namespace Radp\App\Controller;


class Main
{
    /**
     * This function is to register the route
     *
     * @return void
     */
    public function registerRest()
    {

        register_rest_route('woo/v1', '/products', [
            'methods'  => 'GET',
            'callback' => [$this, 'sendWoocommerceProducts'],
        ]);
    }

    /**This function is to send our woocommerce product to the route
     *
     * @return array return the array of our products details
     */
    public function sendWoocommerceProducts(): array
    {
        $args = [
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => -1,
        ];


        $products = get_posts($args);

        $response = [];
        foreach ($products as $product) {
            $wc_product = wc_get_product($product->ID);
            $response[] = [
                'id' => $product->ID,
                'name' => $wc_product->get_name(),
                'price' => $wc_product->get_price(),
                'image' => wp_get_attachment_url($wc_product->get_image_id()),
            ];
        }

        return $response;
    }
}
