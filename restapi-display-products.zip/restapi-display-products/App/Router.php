<?php

namespace Radp\App;


class Router{

    /**
     * This function hold all of our hooks
     *
     * @return void
     */
    public function init(){
        if(is_admin()) return;
        $admin = empty($admin) ? new \Radp\App\Controller\Main() : $admin;
        add_action('rest_api_init',[$admin,'registerRest']);

    }


}