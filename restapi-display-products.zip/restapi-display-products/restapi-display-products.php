<?php

/**
 * Plugin Name: Display Products via REST API
 * Description: This plugin displays WooCommerce products via a custom REST API endpoint.
 * Version: 1.0
 * Author: Sri
 * Slug: restapi-fetch-products
 */

defined("ABSPATH") or exit();
defined("RDP_PLUGIN_NAME") or define("RDP_PLUGIN_NAME", "Display Products via REST API");
defined('RDP_MINIMUM_PHP_VERSION') or define('RDP_MINIMUM_PHP_VERSION', '7.0.0');
defined('RBP_MINIMUM_WP_VERSION') or define('RDP_MINIMUM_WP_VERSION', '4.9');
defined('RDP_MINIMUM_WC_VERSION') or define('RDP_MINIMUM_WC_VERSION', '6.0');

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

if (class_exists('\Radp\App\Helper\CompatabilityCheck')) {
    $compatability_check = new \Radp\App\Helper\CompatabilityCheck();
    if (!$compatability_check->isCompatabilityCheck()) {
        add_action('all_admin_notices', [$compatability_check, 'displayNotices']);
        return;
    }
    if (class_exists('\Radp\App\Router')) {
        $router = new \Radp\App\Router();
        $router->init();
    }
}
