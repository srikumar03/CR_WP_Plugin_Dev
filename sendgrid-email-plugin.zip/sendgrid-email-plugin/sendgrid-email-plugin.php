<?php
/*
Plugin Name: SG-Mail
Description: SendGrid Practice
Version: 1.0
Author: Sri
Text Domain: sg-mail
Domain Path: /languages

 */
function myCustomPluginMenu() {

    add_menu_page(
        __('SG-Mailer', 'sg-mail'),
        __('SG-Plugin', 'sg-mail'),
        'manage_options',
        'SgCustomSlug',
        'SGCustomPage',
        'dashicons-email-alt',
        2
    );
}

function sg_mail_load_textdomain() {
    load_plugin_textdomain('sg-mail', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'sg_mail_load_textdomain');


add_action('admin_menu', 'myCustomPluginMenu');

function SGCustomPage() {

    wc_get_template(
        'main_view.php',
        array(),
        './view/',
        plugin_dir_path(__FILE__) .'./templates/'
    );

}

function enqueueSendgridScripts() {
    if (isset($_GET['page']) && $_GET['page'] === 'SgCustomSlug') {

        // Enqueue your scripts
        wp_enqueue_script('ajax-script', plugin_dir_url(__FILE__) . 'sendgrid-email-script.js', array('jquery'), null, true);

        // Localize script for translation
        wp_localize_script('ajax-script', 'sg_mail_object', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sendgridMailerNonce'),
            'translations' => array(
                'recipient_email_required' => __('Recipient email is required.', 'sg-mail'),
                'invalid_email_format' => __('Invalid email format.', 'sg-mail'),
                'subject_required' => __('Subject is required.', 'sg-mail'),
                'message_content_required' => __('Message content is required.', 'sg-mail'),
                'error_sending_email' => __('There was an error sending the email.', 'sg-mail'),
            )
        ));

        // Enqueue toastr library
        wp_enqueue_script('toastr-js', 'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js', array('jquery'), '2.1.4', true);
        
        // Enqueue toastr styles
        wp_enqueue_style('toastr-css', 'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css', array(), '2.1.4');
        
        // Enqueue custom plugin styles
        wp_enqueue_style('custom-plugin-styles', plugin_dir_url(__FILE__) . 'style.css');
    }
}
add_action('admin_enqueue_scripts', 'enqueueSendgridScripts');

function sendgridSendEmail() {

    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sendgridMailerNonce')) {

        wp_send_json_error(array('message' => __('Security check failed'),'sg-mail'));

    }


    $to = sanitize_email($_POST['to']);

    $subject = sanitize_text_field($_POST['subject']);

    $content = sanitize_textarea_field($_POST['content']);

    $errors = array();

    $required_fields = array(
        'to' => __('Recipient email is required.','sg-mail'),
        'subject' => __('Subject is required.','sg-mail'),
        'content' => __('Message content is required.','sg-mail'),
    );

    foreach ($required_fields as $field => $error_message) {

        if (empty($_POST[$field])) {
   
            $errors[$field] = $error_message;
   
        }

    }

    if (!empty($errors)) {

        wp_send_json_error(array('field_errors' => $errors));

    }

    $apiKey = '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';

    $data = [
        'personalizations' => [
            [
                'to' => [
                    ['email' => $to]
                ],
                'subject' => $subject,
            ],
        ],
        'from' => [
            'email' => 'srissv2003@gmail.com',
        ],
        'content' => [
            [
                'type' => 'text/plain',
                'value' => $content,
            ],
        ],
    ];

    $response = wp_remote_post('https://api.sendgrid.com/v3/mail/send', [
        'headers' => [
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ],
        'body' => json_encode($data),
    ]);

    if (is_wp_error($response)) {
  
        wp_send_json_error(array('message' => __('Error sending email: '),'sg-mail' . $response->get_error_message()));
  
        return;
  
    }

  
    wp_send_json_success(array('message' => __('Email sent to recipient!', 'sg-mail')));
}

add_action('wp_ajax_send_email', 'sendgridSendEmail');



function sgMailAddStyles() {

    echo '
    <style>
    
        .sendgrid-input {
            width: 90%;
            padding: 10px!important;
            margin-top: 8px;
        }
        .sendgrid-textarea {
            width: 90%;
            height: 100px;
            padding: 10px;
            resize: vertical;
            margin-top: 8px;
        }
        .sendgrid-button {
            padding: 10px 20px;
            font-weight: bold;
            font-size: 14px;
            border-radius: 15px;
            background-color: #1d2327;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .sendgrid-clear {
            padding: 10px 20px !important;
            font-weight: bold !important;
            font-size: 14px !important;
            border-radius: 15px !important;
            background-color: red !important;
            color: #fff !important;
            border: none !important;
            cursor: pointer !important;
        }
        .sendgrid-response {
            margin-top: 20px;
        }
    </style>';
}
add_action('admin_head', 'sgMailAddStyles');

