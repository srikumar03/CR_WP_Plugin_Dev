<div class="wrap">
<h1><?php _e('Mail', 'sg-mail'); ?></h1>
<form id="send-email-form">

 
        <input type="email" id="recip" name="to" class="sendgrid-input" placeholder="<?php echo esc_html__('Recipient Email','sg-mail'); ?>" required>

 
        <input type="text" id="subject" name="subject" class="sendgrid-input" placeholder="<?php echo esc_html__('Subject','sg-mail'); ?>" required>


        <textarea id="myTextarea" name="content" class="sendgrid-textarea" placeholder="<?php echo esc_html__('Content', 'sg-mail'); ?>" required></textarea>


        <input type="submit" class="sendgrid-button" value="<?php echo esc_html__('submit', 'sg-mail'); ?>" >

    </form>
    <div id="response" ></div>
</div>

 