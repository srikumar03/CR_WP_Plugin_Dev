jQuery(document).ready(function ($) {
  toastr.options = {
    closeButton: true,
    debug: false,
    newestOnTop: false,
    progressBar: true,
    positionClass: "toast-top-right",
    preventDuplicates: false,
    onclick: null,
    showDuration: "300",
    hideDuration: "1000",
    timeOut: "5000",
    extendedTimeOut: "1000",
    showEasing: "swing",
    hideEasing: "linear",
    showMethod: "fadeIn",
    hideMethod: "fadeOut",
  };

  $("#send-email-form").on("submit", function (e) {
    e.preventDefault();

    // Clear previous error messages
    toastr.clear();
    $(".error-message").remove(); // Remove previous error messages
    $("input, textarea").removeClass("error"); // Remove error class from fields
    $("input, textarea").each(function () {
      $(this).attr("placeholder", $(this).data("original-placeholder"));
      $(this).css("border-color", "");
      $(this).css("color", "");
    });

    var to = $("#recip").val().trim();
    var subject = $("#subject").val().trim();
    var content = $("#content").val().trim();

    var isValid = validateFields(to, subject, content);

    if (isValid) {
      var formData = {
        action: "send_email",
        to: to,
        subject: subject,
        content: content,
        nonce: sg_mail_object.nonce, // Using localized nonce
      };

      $.ajax({
        type: "POST",
        url: sg_mail_object.ajax_url, // Using localized ajax_url
        data: formData,
        success: function (response) {
          if (response.success) {
            toastr.success(response.data.message);
            $("#send-email-form")[0].reset(); // Clear form fields on success
          } else {
            if (response.data.field_errors) {
              $.each(response.data.field_errors, function (field, message) {
                displayError(field, message);
                toastr.error(message);
              });
            } else {
              toastr.error(response.data.message);
            }
          }
        },
        error: function () {
          toastr.error(sg_mail_object.translations.error_sending_email); // Using translated error message
        },
      });
    }
  });

  function validateFields(to, subject, content) {
    var isValid = true;

    if (to === "") {
      displayError(
        "recip",
        sg_mail_object.translations.recipient_email_required
      ); // Using translated message
      isValid = false;
    } else if (!validateEmail(to)) {
      displayError("recip", sg_mail_object.translations.invalid_email_format); // Using translated message
      isValid = false;
    }

    if (subject === "") {
      displayError("subject", sg_mail_object.translations.subject_required); // Using translated message
      isValid = false;
    }

    if (content === "") {
      displayError(
        "content",
        sg_mail_object.translations.message_content_required
      ); // Using translated message
      isValid = false;
    }

    return isValid;
  }

  function displayError(field, message) {
    var $field = $("#" + field);
    $field.attr("placeholder", message);
    $field.css("border-color", "red");
    $field.css("color", "red");
  }

  function validateEmail(email) {
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  $("#recip, #subject, #content").on("input", function () {
    $(this).removeClass("error");
    $(this).next(".error-message").remove();
    $(this).attr("placeholder", $(this).data("original-placeholder"));
    $(this).css("border-color", "");
    $(this).css("color", "");
  });
});
