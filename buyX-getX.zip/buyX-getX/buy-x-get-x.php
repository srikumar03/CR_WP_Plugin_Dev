<?php

/*
Plugin Name: Buy X Get X 
Description: Offer a free product when a customer purchases a specific product.
Version: 1.0
Author: Sri
*/

defined("ABSPATH") or die();
defined("bgx_plugin_path") or define("bgx_plugin_path", plugin_dir_path(__FILE__));
defined("bgx_plugin_url") or define("bgx_plugin_url", plugin_dir_path(__FILE__));

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . "/vendor/autoload.php";
}

if (class_exists('BxGx\App\Router')) {
    $router = new BxGx\App\Router();
    $router->init();
}
