<?php

namespace BxGx\App\Controller;

use BxGx\App\Model\ProductModel;
use BxGx\App\Helper\ProductHelper;

class MainController
{
    public static function applyOffer($cart)
    {
        echo "applyOffer called<br>";
        ProductModel::applyOffer($cart);
    }

    public static function removeFreeItem($cartItemKey, $cart)
    {
        echo "removeFreeItem called<br>";
        ProductModel::removeFreeItem($cartItemKey, $cart);
    }

    public static function hideBxgxProductData($itemData, $cartItem)
    {
        return $itemData;
    }

    public static function setFreeProductPrice($cart)
    {
        echo "setFreeProductPrice called<br>";
        ProductModel::setFreeProductPrice($cart);
    }

    public static function addPluginMenu()
    {
        add_menu_page(
            'Buy X Get X Free Offers',
            'Buy X Get X Free',
            'manage_options',
            'buy-x-get-x-free',
            [self::class, 'renderAdminPage'],
            'dashicons-cart',
            57
        );
    }

    public static function renderAdminPage()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bxgx_nonce'])) {
            if (!wp_verify_nonce($_POST['bxgx_nonce'], 'bxgx_save_selected_products')) {
                return;
            }

            $selectedProducts = isset($_POST['bxgx_selected_products']) ? array_map('intval', $_POST['bxgx_selected_products']) : [];
            update_option('bxgx_selected_products', $selectedProducts);
        }

        // Render the admin page view
        $template = 'DisplayProduct.php';
        wc_get_template($template, [], '', plugin_dir_path(__FILE__) . '../View/');
    }

    public static function renderCustomField()
    {
        $productIds = get_posts([
            'post_type' => 'product',
            'numberposts' => -1,
            'fields' => 'ids'
        ]);

        $selectedProducts = get_post_meta(get_the_ID(), '_bxgx_related_products', true);
        if (!is_array($selectedProducts)) {
            $selectedProducts = [];
        }

        woocommerce_wp_select([
            'id' => '_bxgx_related_products',
            'label' => __('Related Products', 'woocommerce'),
            'description' => __('Select products that will be included in the Buy X Get X Free offer.', 'woocommerce'),
            'options' => wp_list_pluck($productIds, 'post_title', 'ID'),
            'multiple' => true,
            'class' => 'wc-enhanced-select',
            'custom_attributes' => [
                'data-placeholder' => __('Select products', 'woocommerce')
            ],
            'value' => $selectedProducts
        ]);
    }
}

new MainController();
