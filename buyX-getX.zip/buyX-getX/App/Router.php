<?php

namespace BxGx\App;

use BxGx\App\Controller\MainController;
use BxGx\App\Model\ProductModel;

class Router
{
    public function init()
    {
        if (is_admin()) {
            add_action('woocommerce_product_options_general_product_data', [MainController::class, 'renderCustomField']);
            add_action('admin_menu', [MainController::class, 'addPluginMenu']);
        }

        add_action('woocommerce_before_calculate_totals', [MainController::class, 'applyOffer']);
        add_action('woocommerce_cart_item_removed', [MainController::class, 'removeFreeItem'], 10, 2);
        add_filter('woocommerce_get_item_data', [MainController::class, 'hideBxgxProductData'], 10, 2);
        add_action('woocommerce_before_calculate_totals', [MainController::class, 'setFreeProductPrice']);
        add_filter('woocommerce_add_cart_item_data', [ProductModel::class, 'preventFreeProductQuantityChange'], 10, 2);
        add_action('woocommerce_check_cart_items', [ProductModel::class, 'validateFreeProductQuantity']);
    }
}
