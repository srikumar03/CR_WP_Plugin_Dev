<?php
defined('ABSPATH') || exit;

// Get products and selected products from the database
$products = get_posts([
    'post_type' => 'product',
    'numberposts' => -1,
    'fields' => ['ID', 'post_title']
]);

$selectedProducts = get_option('bxgx_selected_products', []);
?>

<div class="wrap">
    <h1><?php _e('Buy X Get X Free Offers', 'woocommerce'); ?></h1>
    <form method="post" action="">
        <?php wp_nonce_field('bxgx_save_selected_products', 'bxgx_nonce'); ?>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><?php _e('Select Products', 'woocommerce'); ?></th>
                <td>
                    <?php foreach ($products as $product) : ?>
                        <label>
                            <input type="checkbox" name="bxgx_selected_products[]" value="<?php echo esc_attr($product->ID); ?>" <?php echo in_array($product->ID, $selectedProducts) ? 'checked' : ''; ?>>
                            <?php echo esc_html($product->post_title); ?>
                        </label><br>
                    <?php endforeach; ?>
                    <p class="description"><?php _e('Select the products that will have the Buy X Get X Free offer.', 'woocommerce'); ?></p>
                </td>
            </tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>