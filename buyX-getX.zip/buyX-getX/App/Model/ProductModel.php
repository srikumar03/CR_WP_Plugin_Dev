<?php

namespace BxGx\App\Model;

use BxGx\App\Helper\ProductHelper;

class ProductModel
{
    public static function applyOffer($cart)
    {
        if (is_admin()) return; // Do not apply the offer in the admin area

        echo "ProductModel applyOffer called<br>";

        $selectedProducts = get_option('bxgx_selected_products', []);

        foreach (ProductHelper::getCartContents() as $cartItemKey => $cartItem) {
            $productId = $cartItem['data']->get_id();

            echo "Checking product in cart: " . $productId . "<br>";

            if (in_array($productId, $selectedProducts)) {
                $hasFreeProduct = false;
                foreach (ProductHelper::getCartContents() as $key => $item) {
                    if (isset($item['bxgx_free']) && $item['data']->get_id() === $productId) {
                        $hasFreeProduct = true;
                        break;
                    }
                }

                if (!$hasFreeProduct) {
                    echo "Adding free product to cart: " . $productId . "<br>";
                    ProductHelper::addToCart($productId, 1, '', '', ['bxgx_free' => true]);
                }
            }
        }
    }

    public static function removeFreeItem($cartItemKey, $cart)
    {
        $removedCartItem = $cart->removed_cart_contents[$cartItemKey];

        if (!isset($removedCartItem['bxgx_free'])) {
            $removedProductId = $removedCartItem['product_id'];

            foreach ($cart->get_cart() as $key => $item) {
                if (isset($item['bxgx_free']) && $item['data']->get_id() === $removedProductId) {
                    $cart->remove_cart_item($key);
                }
            }
        }
    }

    public static function setFreeProductPrice($cart)
    {
        foreach ($cart->get_cart() as $cartItemKey => $cartItem) {
            if (isset($cartItem['bxgx_free']) && $cartItem['bxgx_free']) {
                $cartItem['data']->set_price(0);
            }
        }
    }

    public static function preventFreeProductQuantityChange($cartItemData, $productId)
    {
        if (isset($cartItemData['bxgx_free']) && $cartItemData['bxgx_free']) {
            $cartItemData['quantity'] = 1;
        }

        return $cartItemData;
    }

    public static function validateFreeProductQuantity()
    {
        $cart = ProductHelper::getCart();

        foreach ($cart->get_cart() as $cartItemKey => $cartItem) {
            if (isset($cartItem['bxgx_free']) && $cartItem['bxgx_free'] && $cartItem['quantity'] > 1) {
                wc_add_notice(__('The quantity of free products cannot be increased.', 'woocommerce'), 'error');
                $cart->set_quantity($cartItemKey, 1); // Reset to 1
            }
        }
    }
}
