<?php

namespace BxGx\App\Helper;

class ProductHelper
{
    public static function isCartEmpty()
    {
        $cart = self::getCart();
        return self::isMethodExists($cart, 'is_empty') ? $cart->is_empty() : false;
    }

    public static function getCart()
    {
        return function_exists('WC') && isset(WC()->cart) && WC()->cart instanceof \WC_Cart ? WC()->cart : null;
    }

    public static function isCartValid()
    {
        return !is_null(self::getCart());
    }

    public static function getCartContents()
    {
        $cart = self::getCart();
        return $cart ? $cart->get_cart() : [];
    }

    public static function addToCart($productId, $quantity = 1, $variationId = '', $variation = '', $cartItemData = [])
    {
        $cart = self::getCart();
        if ($cart) {
            echo "Adding product to cart: " . $productId . "<br>";
            $cart->add_to_cart($productId, $quantity, $variationId, $variation, $cartItemData);
        } else {
            echo "Cart is not available<br>";
        }
    }

    private static function isMethodExists($object, $method)
    {
        return is_object($object) && method_exists($object, $method);
    }
}
