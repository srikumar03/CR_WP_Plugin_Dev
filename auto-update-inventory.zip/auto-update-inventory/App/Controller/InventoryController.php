<?php

/**
 * InventoryController Class
 *
 * Manages inventory updates and provides REST API endpoints for inventory operations.
 *
 * @package RestFetch\App\Controller
 */

namespace RestFetch\App\Controller;

use WP_REST_Response;
use WP_REST_Request;

class InventoryController
{
    /**
     * Registers REST API routes.
     */
    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Registers the custom REST API routes for inventory management.
     */
    public function register_routes()
    {
        register_rest_route('rest/v1', '/inventory/update', [
            'methods' => 'POST',
            'callback' => [$this, 'update_inventory'],
            'permission_callback' => [$this, 'permissions_check'],
        ]);
    }

    /**
     * Checks permissions for the REST API request.
     *
     * @return bool
     */
    public function permissions_check()
    {
        return current_user_can('manage_options'); // Change as needed for your use case
    }

    /**
     * Handles the inventory update request.
     *
     * @param WP_REST_Request $request The request object.
     * @return WP_REST_Response
     */
    public function update_inventory(WP_REST_Request $request)
    {
        $updated = $this->process_inventory_update();

        if ($updated) {
            return new WP_REST_Response('Inventory updated successfully', 200);
        } else {
            return new WP_REST_Response('Failed to update inventory', 500);
        }
    }

    /**
     * Processes inventory update.
     *
     * @return bool
     */
    private function process_inventory_update()
    {
        // Fetch products with low stock and update
        $products = $this->get_low_stock_products();
        foreach ($products as $product) {
            $this->restock_product($product);
        }
        return true;
    }

    /**
     * Get products with stock below the threshold.
     *
     * @return array
     */
    private function get_low_stock_products()
    {
        $args = [
            'post_type' => 'product',
            'post_status' => 'publish',
            'meta_query' => [
                [
                    'key' => '_stock',
                    'value' => 500,
                    'compare' => '<',
                    'type' => 'NUMERIC',
                ],
            ],
        ];

        $query = new \WP_Query($args);
        return $query->posts;
    }

    /**
     * Restocks a product.
     *
     * @param \WP_Post $product
     */
    private function restock_product($product)
    {
        $current_stock = get_post_meta($product->ID, '_stock', true);
        $new_stock = $current_stock + 20; // Restock amount
        update_post_meta($product->ID, '_stock', $new_stock);
    }
}
