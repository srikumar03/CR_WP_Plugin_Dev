<?php

/**
 * Router Class
 *
 * Initializes the InventoryController and registers the REST API routes.
 *
 * @package RestFetch\App
 */

namespace RestFetch\App;

use RestFetch\App\Controller\InventoryController;

class Router
{
    /**
     * Initializes the router by setting up REST API routes.
     */
    public function init()
    {
        new InventoryController();
    }
}
