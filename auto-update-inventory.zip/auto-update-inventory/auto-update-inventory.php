<?php

/**
 * Plugin Name: Auto Update Inventory
 * Description: Automatically updates the inventory when product stock goes below 10.
 * Version: 1.0
 * Author: Sri
 */

defined("ABSPATH") or exit();

if (file_exists(__DIR__ . "/vendor/autoload.php")) {
    require_once __DIR__ . "/vendor/autoload.php";
}

use RestFetch\App\Router;

if (class_exists(Router::class)) {
    $router = new Router();
    $router->init();
}
