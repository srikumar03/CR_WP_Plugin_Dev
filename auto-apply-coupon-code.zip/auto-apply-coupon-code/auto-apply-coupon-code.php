<?php

/**
 * Plugin Name: Auto Apply Coupon Code
 * Description: Automatically Apply Coupon Code 
 * Version: 1.8
 * Author: Sri
 */

defined('ABSPATH') or exit();
defined("PLUGIN_NAME") or define("PLUGIN_NAME", "Auto Apply Custom Coupon Code");
defined('AACCC_MIN_PHP_VERSION') or define('AACCC_MIN_PHP_VERSION', '7.0.0');
defined('AACCC_MIN_WP_VERSION') or define('AACCC_MIN_WP_VERSION', '4.9');
defined('AACCC_MIN_WC_VERSION') or define('AACCC_MIN_WC_VERSION', '6.0');


if (file_exists(__DIR__ . "/vendor/autoload.php")) {
    require_once __DIR__ . "/vendor/autoload.php";
}


if (class_exists('\Aacc\App\Helper\CompatabilityCheck')) {
    $compatibility = new \Aacc\App\Helper\CompatabilityCheck();
    if (!$compatibility->Check()) {
        add_action("all_admin_notices", [$compatibility, "compatabilityAlert"]);
        return;
    }
    if (class_exists('\Aacc\App\Router')) {
        $router = new \Aacc\App\Router();
        $router->init();
    }
}
