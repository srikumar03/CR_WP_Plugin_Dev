<?php

namespace Aacc\App\Controller;

class MainCoupon
{


    /**
     * Create and apply custom coupon to cart
     *
     * @return void
     */

    public static function setCouponCode()
    {


        if (class_exists('\Aacc\App\Helper\WcCheck')) {

            $wcCheck = new \Aacc\App\Helper\WcCheck();

            if (!$wcCheck->handleOperation(WC()->session, "get")) return;

            $couponCode = WC()->session->get("autoApplyCoupon");

            if (!$wcCheck->handleOperation(WC()->cart, "get_applied_coupons")) return;

            if (!$couponCode || !in_array($couponCode, WC()->cart->get_applied_coupons())) {

                $shuffledString = (substr(str_shuffle('abcdefghijklmnopqrstuvwxyz0123456789'), 0, 5));


                if (!in_array($shuffledString, WC()->cart->applied_coupons)) {

                    WC()->cart->applied_coupons[] = $shuffledString;

                    if (!$wcCheck->handleOperation(WC()->session, "set")) return;

                    WC()->session->set("autoApplyCoupon", ($shuffledString));
                }
            }
        }
    }

    /**
     * Get the coupon data based on the coupon code
     *work ku var
     * @param mixed $couponList The applied coupon list
     * @param string $couponMatch The coupon code to match
     * @return array The coupon data or the original response if no match
     */
    public static function setCouponCodeData($couponList, $couponMatch)
    {

        $couponCode =  WC()->session->get('autoApplyCoupon');
        if ($couponMatch === $couponCode) {
            return [
                'amount' => 10,
                'discount_type' => 'percent',
                'limit_usage_to_x_items' => '3',
                'minimum_amount' => 50,
                'maximum_amount' => 500,
            ];
        }

        return $couponList;
    }
}
