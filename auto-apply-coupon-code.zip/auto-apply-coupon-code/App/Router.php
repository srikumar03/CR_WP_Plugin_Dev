<?php

namespace Aacc\App;

use \Aacc\App\Controller\MainCoupon;

class Router
{

    /**
     * @return void
     */
    public function init()
    {
        if (is_admin()) return;
        else {
            add_action('woocommerce_before_calculate_totals', [MainCoupon::class, 'setCouponCode'],);
            add_filter('woocommerce_get_shop_coupon_data', [MainCoupon::class, 'setCouponCodeData'], 10, 2);
        }
    }
}
