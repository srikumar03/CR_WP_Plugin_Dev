<?php
namespace DeleteDraftPosts\Models;

class DeleteDraftModel
{
    public static function delete_all_drafts()
    {
        global $wpdb;
        $draft_posts = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'draft'");

        $deleted_drafts = array();


        foreach ($draft_posts as $post) {
            wp_delete_post($post->ID, false);
            $deleted_drafts[] = $post->post_title;

        }
    }
}
