<?php

namespace DeleteDraftPosts\Controllers;

use DeleteDraftPosts\Models\DeleteDraftModel;

class DeleteDraftController
{
    public static function delete_draft_posts()
    {
        DeleteDraftModel::delete_all_drafts();
    }

    public static function schedule_draft_deletion()
    {
        if (!wp_next_scheduled('delete_draft_posts_daily')) {

            $current_time = current_time('timestamp');

            $next_10am = strtotime('10:00:00', $current_time);

            $timezone = new \DateTimeZone(wp_timezone_string());
            $current_time = new \DateTime('now', $timezone);
            $next_10am = new \DateTime('10:00:00', $timezone);

            if ($next_10am <= $current_time) {

                $next_10am->modify('+1 day');
            }

            wp_schedule_event($next_10am->getTimestamp(), 'daily', 'delete_draft_posts_daily');
        }
    }

    public static function delete_draft_posts_menu()

    {

        add_menu_page(
            'Delete Draft Posts',
            'Delete Draft Posts',
            'manage_options',
            'delete-draft-posts',
            [self::class, 'delete_draft_posts_page'],
            'dashicons-trash',
            6
        );
    }

    public static function delete_draft_posts_page()
    {
        $current_time = current_time('mysql');
        $current_timestamp = current_time('timestamp');
        $next_10am = strtotime('10:00:00', $current_timestamp);

        if ($next_10am <= $current_time) {
            $next_10am = strtotime('tomorrow 10:00:00', $current_timestamp);
        }

        $nextSche = date('Y-m-d H:i:s', $next_10am);

        require plugin_dir_path(__FILE__) . '../View/DeleteDraftView.php';
    }
}
