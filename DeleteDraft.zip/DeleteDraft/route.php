<?php

namespace DeleteDraftPosts;

use DeleteDraftPosts\Controllers\DeleteDraftController;

// use DeleteDraftPosts\Models\DeleteDraftModel;

// Initialize the plugin
class Init
{
    public static function register_routes()
    {

        // Schedule the draft deletion event

        add_action('wp', [DeleteDraftController::class, 'schedule_draft_deletion']);

        // Add the admin menu item

        add_action('admin_menu', [DeleteDraftController::class, 'delete_draft_posts_menu']);

        // Hook the function to delete draft posts

        add_action('delete_draft_posts_daily', [DeleteDraftController::class, 'delete_draft_posts']);

        // add_action('init' ,[DeleteDraftModel::class,'delete_all_drafts'] );

    }

}

// Register routes

Init::register_routes();