<?php

/*

* Plugin Name: Delete Draft Posts

* Description: Automatically deletes draft posts every day at 10 am.

* Version: 1.0

* Author: Sri

*/

require_once plugin_dir_path(__FILE__) . 'App/Controller/DeleteDraftController.php';

require_once plugin_dir_path(__FILE__) . 'App/Model/DeleteDraftModel.php';

require_once plugin_dir_path(__FILE__) . 'route.php';