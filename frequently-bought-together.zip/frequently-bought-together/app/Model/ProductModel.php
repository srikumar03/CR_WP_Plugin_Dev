<?php

namespace FBT\Model;

class ProductModel
{
    public function getFrequentlyBoughtTogetherProducts($product_id)
    {
        $fbt_products_ids = get_post_meta($product_id, '_fbt_products', true);
        return $fbt_products_ids ? array_map('trim', explode(',', $fbt_products_ids)) : [];
    }
}
