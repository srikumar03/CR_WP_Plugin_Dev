<?php

namespace FBT\Controller;

use FBT\Model\ProductModel;

class MainController
{
    protected $productModel;

    public function __construct()
    {
        $this->productModel = new ProductModel();
    }

    public function displayFrequentlyBoughtTogether()
    {
        global $product;

        $fbt_products_ids = $this->productModel->getFrequentlyBoughtTogetherProducts($product->get_id());

        if (empty($fbt_products_ids)) {
            echo "No frequently bought together products found.";
            return;
        }

        $product_ids_array = array_map('trim', $fbt_products_ids);

        // Load the view file
        $view_file_path = plugin_dir_path(__FILE__) . '../View/displayProducts.php';
        $view_file_path = realpath($view_file_path); // Resolve relative path to absolute

        if (file_exists($view_file_path)) {
            include $view_file_path;
        } else {
            echo '<p>File does not exist at path: ' . esc_html($view_file_path) . '</p>';
        }
    }
}
