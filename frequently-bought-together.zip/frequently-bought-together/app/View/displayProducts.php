<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly 
?>

<div class="fbt-section">
    <h3>Frequently Bought Together</h3>
    <div class="fbt-products">
        <?php if (!empty($product_ids_array)) : ?>
            <?php foreach ($product_ids_array as $productId) : ?>
                <?php $product = wc_get_product($productId); ?>
                <?php if ($product) : ?>
                    <div class="fbt-product" data-id="<?php echo esc_attr($productId); ?>" data-price="<?php echo esc_html($product->get_price()); ?>">
                        <?php echo esc_html($product->get_image()); ?>
                        <a href="<?php echo esc_url(get_permalink($productId)); ?>">
                            <h4><?php echo esc_html($product->get_name()); ?></h4>
                            <span class="price"><?php echo esc_html($product->get_price_html()); ?></span>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else : ?>
            <p>No frequently bought together products found.</p>
        <?php endif; ?>
    </div>
    <form id="fbt-add-all-to-cart-form" method="post">
        <input type="hidden" name="fbt_add_to_cart" value="1">
        <button id="fbt-add-all-to-cart">Add All to Cart</button>
    </form>
</div>