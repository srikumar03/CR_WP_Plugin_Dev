<?php

class FBT_Routes
{
    public static function init()
    {
        // Load hooks based on request type
        if (is_admin()) {
            // Admin hooks
            add_action('admin_enqueue_scripts', [FrequentlyBoughtTogetherPlugin::class, 'enqueueFbtAssets']);
            add_action('woocommerce_product_options_general_product_data', [FrequentlyBoughtTogetherPlugin::class, 'addFbtCustomField']);
            add_action('woocommerce_process_product_meta', [FrequentlyBoughtTogetherPlugin::class, 'saveFbtCustomField']);
        } else {
            // Frontend hooks
            add_action('wp_enqueue_scripts', [FrequentlyBoughtTogetherPlugin::class, 'enqueueFbtAssets']);
            add_filter('woocommerce_product_tabs', [FrequentlyBoughtTogetherPlugin::class, 'addFbtTab']);
            add_action('wp_loaded', [FrequentlyBoughtTogetherPlugin::class, 'customAddToCart']);
        }
    }
}
