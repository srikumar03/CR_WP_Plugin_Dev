document.addEventListener("DOMContentLoaded", function () {
  // Handle selection
  document.querySelectorAll(".fbt-product").forEach((product) => {
    product.addEventListener("click", function () {
      this.classList.toggle("selected");
    });
  });

  // Handle cart
  document
    .getElementById("fbt-add-all-to-cart")
    .addEventListener("click", function (e) {
      e.preventDefault();
      const selectedIds = Array.from(
        document.querySelectorAll(".fbt-product.selected")
      ).map((product) => product.getAttribute("data-id"));

      if (selectedIds.length > 0) {
        addSelectedToCart(selectedIds);
      }
    });

  // Handle add all to cart
  function addSelectedToCart(productIds) {
    const form = document.getElementById("fbt-add-all-to-cart-form");

    productIds.forEach((id) => {
      const input = document.createElement("input");
      input.type = "hidden";
      input.name = "fbt_product_ids[]";
      input.value = id;
      form.appendChild(input);
    });

    form.submit();
  }
});
