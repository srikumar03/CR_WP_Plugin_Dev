<?php
/*
Plugin Name: Frequently Bought Together
Description: Adds a "Frequently Bought Together" feature to WooCommerce product pages.
Version: 1.0
Author: Sri
*/

defined('ABSPATH') or die();

defined('FBT_STYLE_URL') or define('FBT_STYLE_URL', plugin_dir_url(__FILE__));
defined('FBT_SCRIPT_URL') or define('FBT_SCRIPT_URL', plugin_dir_url(__FILE__));

require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
require_once plugin_dir_path(__FILE__) . 'app/routes.php';

use FBT\Controller\MainController;

class FrequentlyBoughtTogetherPlugin
{
    public function __construct()
    {
        // Initialize the plugin hooks
        FBT_Routes::init();
    }

    // Enqueue scripts and styles
    public static function enqueueFbtAssets()
    {
        $min_suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '.min' : '';
        wp_enqueue_style('fbt-style', FBT_STYLE_URL . 'assets/css/style' . $min_suffix . '.css');
        wp_enqueue_script('fbt-script', FBT_SCRIPT_URL . 'assets/js/script' . $min_suffix . '.js');
    }

    public static function customAddToCart()
    {
        if (!isset($_POST['fbt_add_to_cart']) || empty($_POST['fbt_product_ids'])) {
            return;
        }

        global $woocommerce;
        $product_ids = $_POST['fbt_product_ids'];
        foreach ($product_ids as $product_id) {
            $woocommerce->cart->add_to_cart($product_id);
        }
    }

    // Add custom field with product search and select
    public static function addFbtCustomField()
    {
        global $post;
        $fbt_products = get_post_meta($post->ID, '_fbt_products', true);
        $fbt_products_array = $fbt_products ? explode(',', $fbt_products) : [];
?>
        <div class="options_group">
            <p class="form-field">
                <label for="fbt_products"><?php esc_html__('Frequently Bought Together Products', 'woocommerce'); ?></label>
                <select class="wc-product-search" multiple="multiple" style="width: 50%;" id="fbt_products" name="fbt_products[]" data-placeholder="<?php esc_attr_e('Search for a product&hellip;', 'woocommerce'); ?>" data-action="woocommerce_json_search_products">
                    <?php
                    foreach ($fbt_products_array as $product_id) {
                        $product = wc_get_product($product_id);
                        if ($product) {
                            echo '<option value="' . esc_attr($product_id) . '" selected="selected">' . esc_html($product->get_name()) . '</option>';
                        }
                    }
                    ?>
                </select>
            </p>
        </div>
<?php
    }

    // Save the selected products
    public static function saveFbtCustomField($post_id)
    {
        $fbt_products = isset($_POST['fbt_products']) ? $_POST['fbt_products'] : [];
        $fbt_products = array_map('intval', $fbt_products);
        update_post_meta($post_id, '_fbt_products', implode(',', $fbt_products));
    }

    // Add new tab to product pages
    public static function addFbtTab($tabs)
    {
        $tabs['fbt_tab'] = [
            'title'    => __('Frequently Bought Together', 'woocommerce'),
            'priority' => 1,
            'callback' => [self::class, 'displayFbtTabContent']
        ];
        return $tabs;
    }

    // Display content in the new tab
    public static function displayFbtTabContent()
    {
        $controller = new MainController();
        $controller->displayFrequentlyBoughtTogether();
    }
}

// Initialize the plugin
new FrequentlyBoughtTogetherPlugin();
